'use client'

import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Checkbox } from '@/components/ui/checkbox'
import { toast } from 'sonner'
import { Mail, MessageCircle, ShieldCheck, User, AlertCircle } from 'lucide-react'

export default function ProfilePage() {
  const [phoneNumber, setPhoneNumber] = useState('')
  const [emailConsent, setEmailConsent] = useState(false)
  const [whatsappConsent, setWhatsappConsent] = useState(false)
  const [loading, setLoading] = useState(false)
  const [user, setUser] = useState<any>(null)
  const supabase = createClient()

  useEffect(() => {
    async function loadProfile() {
      const { data: { user } } = await supabase.auth.getUser()
      if (user) {
        setUser(user)
        const { data: profile } = await supabase
          .from('profiles')
          .select('phone, email_consent_granted, whatsapp_consent_granted')
          .eq('id', user.id)
          .single()

        if (profile) {
          setPhoneNumber(profile.phone || '')
          setEmailConsent(profile.email_consent_granted || false)
          setWhatsappConsent(profile.whatsapp_consent_granted || false)
        }
      }
    }
    loadProfile()
  }, [supabase])

  const formatPhoneNumber = (phone: string) => {
    let cleaned = phone.replace(/\D/g, '')
    if (cleaned.startsWith('0')) {
      cleaned = '212' + cleaned.slice(1)
    }
    if (!cleaned.startsWith('212')) {
      cleaned = '212' + cleaned
    }
    return '+' + cleaned
  }

  const handleSave = async () => {
    if (!user) return

    setLoading(true)
    try {
      const formattedPhone = phoneNumber ? formatPhoneNumber(phoneNumber) : null

      const { error } = await supabase
        .from('profiles')
        .update({
          phone: formattedPhone,
          email_consent_granted: emailConsent,
          whatsapp_consent_granted: whatsappConsent,
          consent_updated_at: new Date().toISOString()
        })
        .eq('id', user.id)

      if (error) throw error

      toast.success('Profil mis à jour avec succès !')
    } catch (error: any) {
      toast.error(error.message || 'Erreur lors de la mise à jour du profil')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="w-full py-8 px-4 bg-[#F5F7FA] min-h-full">
      <div className="max-w-md mx-auto space-y-6">
        <Card className="border-[#E7E5EC] shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-[#1A1A2E]">
              <User className="w-5 h-5 text-[#7C5CFC]" />
              Paramètres du profil
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="space-y-1">
              <Label className="text-[#6B6B7A]">E-mail</Label>
              <p className="text-sm font-medium text-[#1A1A2E]">{user?.email}</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone" className="text-[#6B6B7A]">Numéro WhatsApp</Label>
              <Input
                id="phone"
                type="tel"
                placeholder="06 12 34 56 78"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                className="border-[#DAD7E3] focus-visible:ring-[#7C5CFC]"
              />
              <p className="text-xs text-[#6B6B7A]">
                Format : 06 12 34 56 78 (numéro marocain)
              </p>
            </div>

            <div className="border-t border-[#E7E5EC] pt-4">
              <h3 className="font-semibold mb-3 text-[#1A1A2E]">Préférences de notification</h3>

              <div className="flex items-start space-x-3 p-3 bg-[#F5F7FA] border border-[#E7E5EC] rounded-lg">
                <Checkbox
                  id="email-consent"
                  checked={emailConsent}
                  onCheckedChange={(checked) => setEmailConsent(!!checked)}
                  className="mt-1 data-[state=checked]:bg-[#14B8A6] data-[state=checked]:border-[#14B8A6]"
                />
                <div>
                  <Label htmlFor="email-consent" className="font-medium text-[#1A1A2E] flex items-center gap-1.5">
                    <Mail className="w-4 h-4 text-[#14B8A6]" />
                    Notifications par e-mail
                  </Label>
                  <p className="text-xs text-[#6B6B7A] mt-0.5">
                    Recevoir les mises à jour de disponibilité des salles par e-mail
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3 p-3 bg-[#F5F7FA] border border-[#E7E5EC] rounded-lg mt-2">
                <Checkbox
                  id="whatsapp-consent"
                  checked={whatsappConsent}
                  onCheckedChange={(checked) => setWhatsappConsent(!!checked)}
                  className="mt-1 data-[state=checked]:bg-[#7C5CFC] data-[state=checked]:border-[#7C5CFC]"
                />
                <div>
                  <Label htmlFor="whatsapp-consent" className="font-medium text-[#1A1A2E] flex items-center gap-1.5">
                    <MessageCircle className="w-4 h-4 text-[#7C5CFC]" />
                    Notifications WhatsApp
                  </Label>
                  <p className="text-xs text-[#6B6B7A] mt-0.5">
                    Recevoir les mises à jour de disponibilité des salles sur WhatsApp
                  </p>
                  {whatsappConsent && !phoneNumber && (
                    <p className="text-xs text-[#E2624F] mt-1 flex items-center gap-1">
                      <AlertCircle className="w-3.5 h-3.5" />
                      Ajoutez votre numéro WhatsApp ci-dessus
                    </p>
                  )}
                </div>
              </div>
            </div>

            <Button
              onClick={handleSave}
              disabled={loading}
              className="w-full bg-[#7C5CFC] hover:bg-[#6242D6]"
            >
              {loading ? 'Enregistrement...' : 'Enregistrer les modifications'}
            </Button>
          </CardContent>
        </Card>

        <div className="p-4 bg-[#F3F0FF] rounded-lg border border-[#DDD5FA]">
          <h3 className="font-semibold text-[#5B3FD6] flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4" />
            Votre confidentialité
          </h3>
          <p className="text-sm text-[#5B3FD6]/80 mt-1">
            Nous respectons votre vie privée. Vous pouvez modifier vos préférences de consentement à tout moment.
            Nous ne partageons jamais vos données avec des tiers.
          </p>
          <p className="text-xs text-[#5B3FD6]/70 mt-2">
            L'historique de consentement est conservé à des fins de conformité
          </p>
        </div>
      </div>
    </div>
  )
}