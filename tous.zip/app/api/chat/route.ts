import { NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { GoogleGenAI } from '@google/genai'

// ⚠️ Cette clé ne doit JAMAIS être exposée côté client.
// Cette route tourne uniquement côté serveur (Next.js API route).
const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY })

// gemini-flash-latest : alias qui pointe toujours vers le dernier modèle Flash
// disponible gratuitement (actuellement gemini-3.5-flash, juillet 2026).
// Utiliser l'alias plutôt qu'un nom figé évite de devoir corriger ce fichier
// à chaque fois que Google fait évoluer sa gamme de modèles.
const MODEL = 'gemini-flash-latest'

// ---------------------------------------------------------------------------
// 1. Déclaration des outils que le modèle peut appeler
// ---------------------------------------------------------------------------
const tools = [
  {
    functionDeclarations: [
      {
        name: 'get_free_rooms',
        description:
          "Retourne la liste des salles actuellement libres (hors salles hors service et hors espace détente).",
        parameters: { type: 'object', properties: {} }
      },
      {
        name: 'get_occupied_rooms',
        description:
          "Retourne la liste des salles actuellement occupées, avec le nombre de personnes présentes et l'heure de fin prévue.",
        parameters: { type: 'object', properties: {} }
      },
      {
        name: 'get_room_details',
        description: "Retourne les détails d'une salle précise à partir de son nom (ou une partie du nom).",
        parameters: {
          type: 'object',
          properties: {
            room_name: { type: 'string', description: 'Nom (ou fragment de nom) de la salle recherchée' }
          },
          required: ['room_name']
        }
      },
      {
        name: 'get_stats',
        description:
          "Retourne les statistiques globales d'occupation : taux d'occupation, salles confidentielles, salles hors service, etc.",
        parameters: { type: 'object', properties: {} }
      },
      {
        name: 'get_bookings',
        description: 'Retourne les réservations à venir sur une période donnée.',
        parameters: {
          type: 'object',
          properties: {
            period: {
              type: 'string',
              enum: ['today', 'week', 'month'],
              description: 'Période à consulter : aujourd\'hui, cette semaine, ou ce mois-ci'
            }
          },
          required: ['period']
        }
      },
      {
        name: 'get_history',
        description: 'Retourne les dernières activités enregistrées (occupations et libérations de salles).',
        parameters: {
          type: 'object',
          properties: {
            limit: { type: 'number', description: 'Nombre d\'événements à retourner (10 par défaut)' }
          }
        }
      }
    ]
  }
]

// ---------------------------------------------------------------------------
// 2. Exécution réelle des outils contre Supabase (données toujours fraîches)
// ---------------------------------------------------------------------------
async function executeTool(name: string, args: any, supabase: any) {
  switch (name) {
    case 'get_free_rooms': {
      const { data } = await supabase.from('rooms').select('*')
      const free = (data || []).filter(
        (r: any) => !r.is_occupied && !r.is_out_of_service && r.category !== 'detente'
      )
      return free.map((r: any) => ({
        name: r.name,
        location: r.location,
        capacity: r.capacity,
        equipment: r.equipment
      }))
    }

    case 'get_occupied_rooms': {
      const { data } = await supabase.from('rooms').select('*')
      const occupied = (data || []).filter((r: any) => r.is_occupied)
      return occupied.map((r: any) => ({
        name: r.name,
        current_people: r.current_people,
        max_people: r.max_people || r.capacity,
        occupied_until: r.occupied_until
      }))
    }

    case 'get_room_details': {
      const { data } = await supabase.from('rooms').select('*').ilike('name', `%${args.room_name}%`)
      return data || []
    }

    case 'get_stats': {
      const { data: rooms } = await supabase.from('rooms').select('*')
      const total = rooms?.length || 0
      const occupied = rooms?.filter((r: any) => r.is_occupied).length || 0
      return {
        total_rooms: total,
        free_rooms: total - occupied,
        occupied_rooms: occupied,
        occupancy_rate: total > 0 ? Math.round((occupied / total) * 100) : 0,
        confidential_rooms: rooms?.filter((r: any) => r.is_confidential).length || 0,
        out_of_service_rooms: rooms?.filter((r: any) => r.is_out_of_service).length || 0
      }
    }

    case 'get_bookings': {
      const now = new Date()
      let start: Date
      let end: Date

      if (args.period === 'today') {
        start = new Date(now)
        end = new Date(now)
        end.setDate(end.getDate() + 1)
      } else if (args.period === 'week') {
        start = new Date(now)
        end = new Date(now)
        end.setDate(end.getDate() + 7)
      } else {
        start = new Date(now.getFullYear(), now.getMonth(), 1)
        end = new Date(now.getFullYear(), now.getMonth() + 1, 0)
      }

      const { data } = await supabase
        .from('bookings')
        .select('*, rooms(name)')
        .gte('booking_date', start.toISOString().split('T')[0])
        .lte('booking_date', end.toISOString().split('T')[0])

      return (data || []).map((b: any) => ({
        room: b.rooms?.name,
        date: b.booking_date,
        start: b.start_time,
        end: b.end_time,
        title: b.title
      }))
    }

    case 'get_history': {
      const { data } = await supabase
        .from('room_history')
        .select('*, rooms(name)')
        .order('changed_at', { ascending: false })
        .limit(args.limit || 10)

      return (data || []).map((h: any) => ({
        room: h.rooms?.name,
        status: h.is_occupied ? 'Occupée' : 'Libre',
        changed_at: h.changed_at
      }))
    }

    default:
      return { error: `Outil inconnu: ${name}` }
  }
}

const SYSTEM_INSTRUCTION = `Tu es l'assistant IA de MDI RoomPulse, une application de gestion de salles.
Réponds toujours en français, de façon concise et utile.
Utilise TOUJOURS les outils fournis pour obtenir des données à jour avant de répondre — ne devine JAMAIS
l'état des salles, des réservations ou des statistiques : ces données changent en temps réel.
Formate tes réponses avec des puces et des emojis pertinents (🟢 libre, 🔴 occupée, 📅 réservation, 📋 historique)
pour rester lisible, comme un petit tableau de bord.`

// ---------------------------------------------------------------------------
// 3. Route POST — boucle d'appel d'outils avec Gemini
// ---------------------------------------------------------------------------
export async function POST(request: Request) {
  try {
    if (!process.env.GEMINI_API_KEY) {
      return NextResponse.json(
        { error: 'GEMINI_API_KEY manquante. Ajoutez-la dans .env.local puis redémarrez le serveur.' },
        { status: 500 }
      )
    }

    const { messages } = (await request.json()) as {
      messages: { role: 'user' | 'assistant'; content: string }[]
    }

    const supabase = await createClient()

    // Historique converti au format attendu par Gemini (roles 'user' / 'model')
    const contents: any[] = messages.map((m) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }]
    }))

    // Boucle de sécurité : au maximum 5 aller-retours d'appels d'outils
    for (let i = 0; i < 5; i++) {
      const response = await genAI.models.generateContent({
        model: MODEL,
        contents,
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          tools,
          // Le mode "thinking" de Gemini exige de renvoyer un thought_signature
          // avec chaque appel de fonction dans l'historique — plusieurs SDK (dont
          // celui-ci) ont des bugs connus qui font perdre cette signature en route,
          // ce qui casse le function calling. On désactive le thinking : inutile
          // pour de simples appels d'outils, et ça évite complètement le problème.
          thinkingConfig: { thinkingBudget: 0 }
        }
      })

      const calls = response.functionCalls

      if (!calls || calls.length === 0) {
        return NextResponse.json({ reply: response.text })
      }

      // On renvoie les parts EXACTEMENT telles que Gemini les a produites (pas une
      // version reconstruite à la main), car chaque functionCall porte un
      // thought_signature attaché par Google qu'il faut impérativement préserver
      // tel quel dans l'historique — sinon l'appel suivant échoue avec une erreur 400
      // "missing thought_signature". Voir : https://ai.google.dev/gemini-api/docs/thought-signatures
      const modelParts =
        response.candidates?.[0]?.content?.parts ??
        calls.map((c: any) => ({ functionCall: { name: c.name, args: c.args } }))

      contents.push({
        role: 'model',
        parts: modelParts
      })

      const functionResponseParts = []
      for (const call of calls) {
        const result = await executeTool(call.name, call.args, supabase)
        functionResponseParts.push({
          functionResponse: { name: call.name, response: { result } }
        })
      }
      contents.push({ role: 'user', parts: functionResponseParts })
    }

    return NextResponse.json({ reply: "Désolé, je n'ai pas réussi à traiter votre demande." })
  } catch (error: any) {
    console.error('Chat API error:', error)
    return NextResponse.json({ error: error.message || 'Erreur serveur' }, { status: 500 })
  }
}

// ---------------------------------------------------------------------------
// 🔮 Pour plus tard, quand vous aurez vos documents (politique de réservation, FAQ...) :
// Ajoutez un 7e outil `search_knowledge_base(query)` qui fait une recherche par similarité
// dans une table Postgres avec pgvector (déjà disponible sur Supabase, pas besoin d'un
// service externe). Le reste de cette architecture (boucle d'outils) ne change pas —
// c'est juste un outil de plus dans la liste `tools`. Dites-moi quand vous avez les
// documents, je vous fais l'ingestion + la fonction de recherche.
// ---------------------------------------------------------------------------